This program should really only be done in double precision.
To execute the code, make sure everything is in the current directory and type

g++ -std=c++11 -DDOUBLE=1 main.cpp
