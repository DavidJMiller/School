To execute the code type

g++ -std=c++11 -DDOUBLE=1 main.cpp
