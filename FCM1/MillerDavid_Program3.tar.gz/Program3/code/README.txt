To run the code with double precision 

	g++ -std=c++11 -DDOUBLE=1 main.cpp

To run the code with single precision

	g++ -std=c++11 -DSINGLE=1 main.cpp

The main function is used as a place to call functions and spit out results. 